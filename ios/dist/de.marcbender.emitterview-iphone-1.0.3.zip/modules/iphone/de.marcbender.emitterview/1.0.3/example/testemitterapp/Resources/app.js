/**
 * titanium-emitterview — Simple Confetti Demo
 */

var emitterViewModule = require('de.marcbender.emitterview');

var win = Ti.UI.createWindow({
    title: 'Confetti Demo',
    backgroundColor: '#fff'
});

// Create confetti emitter using named constants
var confettiEmitter = emitterViewModule.createView({
    top: 0, left: 0, right: 0, bottom: 0,
    width: Ti.UI.FILL,
    height: Ti.UI.FILL,
    particleType: emitterViewModule.PARTICLE_CONFETTI,
    direction: emitterViewModule.DIRECTION_DOWN,
    intensity: 0.8,
    colors: [
        '#FF6B6B', '#4ECDC4', '#FFE66D',
        '#A8E6CF', '#FF8B94', '#DDA0DD'
    ],
    velocity: 400,
    velocityRange: 120,
    spin: 360,
    spinRange: 180,
    amplitude: 10,
    maxAmplitude: 20
});

win.add(confettiEmitter);

// Create button
var button = Ti.UI.createView({
    width: 100,
    height: 100,
    bottom: 100,
    right: 20,
    borderRadius: 50,
    backgroundColor: '#e94560'
});

var label = Ti.UI.createLabel({
    text: '🎉',
    font: { fontSize: 40 },
    width: Ti.UI.SIZE,
    height: Ti.UI.SIZE,
    left: 30,
    top: 30
});

button.add(label);
win.add(button);

// Test with emitImage (legacy method)
button.addEventListener('touchstart', function () {
    Ti.API.info('Button tapped, calling emitImage()...');
    confettiEmitter.emitImage({ sourceView: button });
    Ti.API.info('emitImage() completed!');
});

win.open();
